import sys
import getopt
import socket
import Checksum
import BasicSender
import random

'''
This is a skeleton sender class. Create a fantastic transport protocol here.
'''
class Sender(BasicSender.BasicSender):
    def __init__(self,dest,port,filename,debug=False):
        self.debug = debug
        self.dest = dest
        self.dport = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(None) # blocking
        self.sock.bind(('',random.randint(10000,40000)))
        if filename == None:
            self.infile = sys.stdin
        else:
            self.infile = open(filename,"r")

# Handles a response from the receiver.
    def handle_response(self,response_packet):
        if Checksum.validate_checksum(response_packet):
            return True
        else:
            return False

    def print_list(self,lst):
        for element in lst:
            print "%s" % element


    # Main sending loop.
    def start(self):
        MAX_FRAME_SIZE = 1472
        #print("initializing...")
        seqno = 0
        packets = []

        #Read file and put into packets
        #print("reading from file")
        template_length = len("start|seq||0123456789")
        packetData = self.infile.read(MAX_FRAME_SIZE - template_length)
        while (not packetData == ""):
            if not seqno == 0:
                packets.append(self.make_packet('data', seqno, packetData))
            else:
                packets.append(self.make_packet('start', seqno, packetData))
            seqno += 1
            packetData = self.infile.read(MAX_FRAME_SIZE - template_length)
        #print("file has been read")
        #print("the length of data is %d") % len(packets)
        packets.append(self.make_packet('end', seqno, ''))

        #Read first 5 elements from file and populate ulist & send_list
        i = 0
        send_list = []
        ulist = []
        while i < 5:
            if not len(packets) == 0:
                msg = packets.pop(0)
                send_list.append(msg)
                ulist.append(msg)
            i += 1    
        #print("first five elements read from file")

        #Read next 5 elements from file and populate next_list
        i = 0
        next_list = []
        while i < 5:
            if len(packets) == 0:
                break
            else:
                next_list.append(packets.pop(0))
            i += 1
        #print("next five elements read from file")

        #print "the length of next_list is: %d" % len(next_list)
        #print "the length of send_list is: %d" % len(send_list)
        #print "the length of ulist is %d" % len(ulist)
        #Send first five elements 
        for packet in send_list:

            self.send(packet)
        #print "first %d elements sent" % len(send_list)

        #print "the length of next_list is: %d" % len(next_list)
        #print "the length of send_list is: %d" % len(send_list)
        #print "the length of ulist is %d" % len(ulist)

        while len(ulist) > 0:
            #print "checking for acks"
            response = self.receive(0.5)
            if response == None:
                if not len(ulist) == 0:
                    #print "TIMEOUT"
                    self.send(ulist[0])   
            else:
                not_corrupt = self.handle_response(response)     
                if not_corrupt:
                    splitPacket = self.split_packet(response)
                    ackNumber = splitPacket[1]
                    #print "Received an ack"
                    tmpsend_list = []
                    i = 0
                    #print "ackNumber is: %d" % float(ackNumber)
                    #print "lenght of send_list is: %d" % len(send_list)
                    #print "length of ulist is: %d" % len(ulist)
                    splitPacket = self.split_packet(ulist[0])
                    unAck = splitPacket[1]
                    #print "unAck is: %d" % float(unAck)
                    while float(ackNumber) > float(unAck):
                        #print "ackNumber is: %d" % float(ackNumber)
                        #print "popping something off ulist"
                        if len(ulist) == 0:
                            #print "BREAKING SINCE LEN(ULIST) == 0"
                            break
                        else:
                            ulist.pop(0)
                            if not len(ulist) == 0:
                                splitPacket = self.split_packet(ulist[0])
                                unAck = splitPacket[1]
                            else:
                                break
                        i += 1
                    while i > 0:
                        if not len(next_list) == 0:
                            next = next_list.pop(0)
                            ulist.append(next)
                            tmpsend_list.append(next)
                        if not len(packets) == 0:
                            #print "popping something off packets"
                            msg = packets.pop(0)
                            next_list.append(msg)
                        #print "data is now of length: %d" % len(packets)
                        i += -1

                    #send list + ulist[0]
                    for data in tmpsend_list:
                        self.send(data)

        #print "SENDING COMPLETION MESSAGE"
        #print "END: the length of data is: %d" % len(packets)
        #print "END: the lenght of ulist is: %d" % len(ulist)

            

           

'''
This will be run if you run this script from the command line. You should not
change any of this; the grader may rely on the behavior here to test your
submission.
'''
if __name__ == "__main__":
    def usage():
        print "BEARS-TP Sender"
        print "-f FILE | --file=FILE The file to transfer; if empty reads from STDIN"
        print "-p PORT | --port=PORT The destination port, defaults to 33122"
        print "-a ADDRESS | --address=ADDRESS The receiver address or hostname, defaults to localhost"
        print "-d | --debug Print debug messages"
        print "-h | --help Print this usage message"

    try:
        opts, args = getopt.getopt(sys.argv[1:],
                               "f:p:a:d", ["file=", "port=", "address=", "debug="])
    except:
        usage()
        exit()

    port = 33122
    dest = "localhost"
    filename = None
    debug = False

    for o,a in opts:
        if o in ("-f", "--file="):
            filename = a
        elif o in ("-p", "--port="):
            port = int(a)
        elif o in ("-a", "--address="):
            dest = a
        elif o in ("-d", "--debug="):
            debug = True

    s = Sender(dest,port,filename,debug)
    try:
        s.start()
    except (KeyboardInterrupt, SystemExit):
        exit()
