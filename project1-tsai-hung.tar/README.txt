(1) Harrison Tsai, Stanley Hung
(2) Desiging the data structures, how each data structure related to each other
